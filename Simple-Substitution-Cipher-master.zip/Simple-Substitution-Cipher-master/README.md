# Simple-Substitution-Cipher
An implementation of a basic simple substitution cipher in Java.
