
public class Letter {
	char value;
	int freq;
	
	public Letter(char v, int f) {
		
		value = v;
		freq = f;
		
	}
}
